# -*- coding: utf-8 -*-

#__all__ = ['numpy.array']
#from numpy import (array, dot, arccos, clip) 
#from numpy.linalg import norm 